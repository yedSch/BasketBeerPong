﻿using UnityEngine;
using System;
using UnityEngine.Events;

[Serializable]
public class ColorChangedEvent : UnityEvent<Color>
{

}