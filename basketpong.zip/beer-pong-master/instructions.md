ARKit requires an iPhone 6s (or SE), iPad (5th generation), iPad Pro, or newer.

* Stand up in a well-lit room
* Look around until you see a red rectangle on the floor
* Tap the red rectangle to place the table there
* Walk around the table to position your shot
* Tap anywhere on the screen to shoot the ball into the cups
* Aim by moving closer/farther from the table and adjusting the angle of your camera
* Shutdown and re-open the app to reset
